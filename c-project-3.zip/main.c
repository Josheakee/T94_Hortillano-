/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main(){
int temp;
printf("Please input Temperature ");
scanf("%d", &temp);
if(temp <=0){
  printf(" The weather is freezing");
}
else if(temp>=0 && temp<=10){
  printf(" The weather is very cold");
  }
else if(temp>=10 && temp<=20){
  printf("The weather is cold");
}
else if(temp>=20 && temp<=30){
  printf("The weather is normal");
} 
else if(temp>=30 && temp<=40){
  printf("The weather is hot");
}
else if(temp>=40){
  printf("The weather very hot");
}
return 0;
}






